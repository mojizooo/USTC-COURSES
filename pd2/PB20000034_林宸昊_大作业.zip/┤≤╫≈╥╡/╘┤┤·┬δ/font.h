#ifndef FONT_H
#define FONT_H

#include <QFont>
#include <QString>
#include <vector>

QFont fitted_font(QFont font);

#endif // FONT_H

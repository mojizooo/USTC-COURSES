#include <font.h>

QFont fitted_font(QFont font)
{
    font.setPointSize(20);
    return font;
}

# Lab3

## Part2

Resources for lab3 of OS2022.

Plz check lab directory(`lab3-v1.1`) lab doc v1.12 (`lab3.2-v1.12.pdf`)

and `solution.txt` for detailed information.

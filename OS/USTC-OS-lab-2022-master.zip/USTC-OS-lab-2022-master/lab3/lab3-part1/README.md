# Lab3

## Part1

Resource for lab3 of OS2022.

Plz check `lab3-alloc-v1.1` for detailed information.


# Simple_FAT16
A simple FAT16 file system, supporting read, touch and remove file. \
An Operating System course work @USTC-CS, 2021 Spring

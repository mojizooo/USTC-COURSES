#! /bin/bash

g++ -std=c++11 workload.cc -o lab3_workload -lpthread
./lab3_workload

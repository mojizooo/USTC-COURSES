void main(void)
{
    int a = 1234;
    
    return;
}

# 组员贡献

## 贡献详述

### 吕瑞 PB18111707

1. ASTProgram
2. ASTNum
3. ASTVarDeclaration
4. ASTFunDeclaration
5. ASTParam
6. ASTCompoundStmt
7. ASTAssignExpression
8. ASTSimpleExpression
9. ASTCall（参数列表的比较）
10. 去除同一块内 return 后冗余的 IR 语句

### 谭泽霖 PB18010454

1. ASTExpressionStmt
2. ASTSelectionStmt
3. ASTIterationStmt
4. ASTReturnStmt
5. ASTVar

### 艾语晨 PB18000227

1. ASTAdditiveExpression
2. ASTTerm
3. ASTCall（基础处理）

## 评定结果

|名字|百分比|
|:-:|:-:|
|吕瑞|51%|
|谭泽霖|33%|
|艾语晨|16%|

百分比相加应当等于100%

可以对特殊情况进行备注
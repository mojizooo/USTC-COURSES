#include "cminus_builder.hpp"
#include <iostream>

// You can define global variables here
// to store state

void CminusBuilder::visit(syntax_program &node) {}

void CminusBuilder::visit(syntax_num &node) {}

void CminusBuilder::visit(syntax_var_declaration &node) {}

void CminusBuilder::visit(syntax_fun_declaration &node) {}

void CminusBuilder::visit(syntax_param &node) {}

void CminusBuilder::visit(syntax_compound_stmt &node) {}

void CminusBuilder::visit(syntax_expresion_stmt &node) {}

void CminusBuilder::visit(syntax_selection_stmt &node) {}

void CminusBuilder::visit(syntax_iteration_stmt &node) {}

void CminusBuilder::visit(syntax_return_stmt &node) {}

void CminusBuilder::visit(syntax_var &node) {}

void CminusBuilder::visit(syntax_assign_expression &node) {}

void CminusBuilder::visit(syntax_simple_expression &node) {}

void CminusBuilder::visit(syntax_additive_expression &node) {}

void CminusBuilder::visit(syntax_term &node) {}

void CminusBuilder::visit(syntax_call &node) {}
